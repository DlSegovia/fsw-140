import React, { useState } from 'react';
import PetForm from './PetForm';

export default function Pets(props) {
  const { name, imgURL, breed, petID } = props
  const [editToggle, setEditToggle] = useState(false)
  // debugger
  const imageURL = "http://192.168.0.11:3000/images/" + imgURL;
  return (
    <div className='Pets'>
      {!editToggle ? (
        <>
          <h1>Name: {name}</h1>
          <img src={imageURL} width="25%" height="25%" alt=" "></img>
          <p>Breed: {breed}</p>
          <button className='del-btn'
            onClick={() => props.deletePets(petID)}>
            Delete
      </button>
          <button className='edit-btn'
            onClick={() => setEditToggle(prevToggle => !prevToggle)}>
            Edit
      </button>
        </>
      ) : (
          <>
            <PetForm
              name={name}
              imgURL={imgURL}
              breed={breed}
              petID={petID}
              btnText='Submit Edit'
              submit={props.editPets} />

            <button onClick={() => setEditToggle(prevToggle => !prevToggle)}>
              Close
        </button>
          </>
        )}
    </div>
  )
}