import React, { useState, useEffect } from "react";
import axios from "axios";
import PetForm from "./components/PetForm.js";
import Pets from "./components/Pets.js";

export default function App() {
  const [pets, setPets] = useState([])

  function getPets() {
    axios.get("http://localhost:3030/selectdb")
      .then(res => {
console.log(res)
        setPets(res.data)
      })
      .catch(err => console.log(err))
  }

  function addPets(newPets) {
    axios.post("http://localhost:3030/postdb", newPets)
      .then(res => {
        setPets(prevPets => [...prevPets, res.data])
      })
      .catch(err => console.log(err))
  }

  function deletePets(PetsId) {
    
    axios.delete(`http://localhost:3030/deletedb/${PetsId}`)
      .then(res => {
        setPets(prevPets =>
          prevPets.filter(Pets => Pets._id !== PetsId)
        )
      })
      .catch(err => console.log(err))
  }

  function editPets(updates, PetsId) {
    axios.put(`http://localhost:3030/Pets/${PetsId}`, updates)
      .then(res => {
        setPets(prevPets =>
          prevPets.map(Pets => (Pets._id !== PetsId ? Pets : res.data))
        )
      })
      .catch(err => console.log(err))
  }

  useEffect(() => {
  getPets()
  }, [])

  return (
    <div>
      <div>
        <PetForm
          submit={addPets}
          btnText='Add Pets'/>

          {pets.map((pets,i) => (
            <Pets
            {...pets}
            key={i}
            imgURL = {pets.imgURL}
            deletePets={deletePets}
            editPets={editPets}/>
          ))}
      </div>
    </div>
  )
}