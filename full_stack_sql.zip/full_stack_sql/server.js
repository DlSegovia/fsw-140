const express = require("express");
const app = express();
const cors=require("cors")
const mysql = require("mysql");

app.use(express.json())
app.use(cors())

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "secret",
    database: "petdb",
});
db.connect((err) => {
    if (err){
        throw err;
    }
    console.log("connected to MySQL");
});

app.get("/createdb",(req,res) => {
    let sql = "CREATE DATABASE petdb";
    db.query(sql,(err,result) => {
        if(err){
            throw err;
        }
    console.log(result)
    // res.send("database is created")
    

    let sql = "USE petdb";
    db.query(sql,(err,result) => {
        if(err){
            throw err;
        }

        let sql = "CREATE TABLE `pets` (`petID` int unsigned NOT NULL AUTO_INCREMENT, `name` varchar(45) NOT NULL, `age` varchar(45) DEFAULT NULL, `breed` varchar(45) NOT NULL, `color` varchar(45) DEFAULT NULL, `imgURL` varchar(45) NOT NULL, PRIMARY KEY (`petID`)); ";
        db.query(sql,(err,result) => {
            if(err){
                throw err;
            }
            res.send("usingpetdb Database")
        })
    }) })  })


app.get("/selectdb",(req,res) => {
    let sql = "select * from pets;";
    db.query(sql,(err,result) => {
        if(err){
            throw err;
        }
        res.send(result)
    })
})

app.post("/postdb",(req,res) => {
    console.log(req.body)
    let sql = `INSERT INTO pets (name,age,breed,color,imgURL) VALUES ("${req.body.name}","${req.body.age}","${req.body.breed}","${req.body.color}","${req.body.imgURL}");`;
    db.query(sql,(err,result) => {
        if(err){
            throw err;
        }
        res.send("usingpetdb Database")
    })
})

app.delete("/deletedb/:id",(req,res) => {
    let sql = `delete from pets where petID = ${req.params.id};`;
    db.query(sql,(err,result) => {
        if(err){
            throw err;
        }
        res.send(result)
    })
})

app.edit("/editdb/:id",(req,res) => {
    let sql = `edit from pets where petID = ${req.params.id};`;
    db.query(sql,(err,result) => {
        if(err){
            throw err;
        }
        res.send(result)
    })
})

app.use((err,req,next) => {
    console.log(err);F
    if(err.name ==="Unauthorized"){
        res.status(err.status);
    }
    return res.send({ errMsg: err.message });
});

app.listen(3030,() =>{
    console.log("Server is running on port 3030");
});

